import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import LoginPage from '@/pages/LoginPage';
import SignUpPage from '@/pages/SignUpPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import HomePage from '@/pages/HomePage';
import InternsPage from '@/pages/InternsPage';
import HRPage from '@/pages/HRPage';
import ProjectsPage from '@/pages/ProjectsPage';
import EmployeesPage from '@/pages/EmployeesPage';
import ActivityLogPage from '@/pages/ActivityLogPage';
import { supabase } from '@/lib/supabaseClient';
import { addLog } from '@/lib/logger';

const ProtectedRoute = ({ children, isAuthenticated }) => {
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate(); 

  useEffect(() => {
    const checkUserSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        setIsAuthenticated(true);
        setCurrentUser(session.user.user_metadata?.name || session.user.email);
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('currentUser', session.user.user_metadata?.name || session.user.email);
      } else {
        setIsAuthenticated(false);
        setCurrentUser(null);
        localStorage.removeItem('isAuthenticated');
        localStorage.removeItem('currentUser');
      }
      setLoadingAuth(false);
    };

    checkUserSession();

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN') {
        setIsAuthenticated(true);
        setCurrentUser(session.user.user_metadata?.name || session.user.email);
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('currentUser', session.user.user_metadata?.name || session.user.email);
      } else if (event === 'SIGNED_OUT') {
        setIsAuthenticated(false);
        setCurrentUser(null);
        localStorage.removeItem('isAuthenticated');
        localStorage.removeItem('currentUser');
        navigate('/login');
      }
    });
    
    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [navigate]);


  const handleLogin = async (user) => {
    setIsAuthenticated(true);
    setCurrentUser(user.name || user.email);
    localStorage.setItem('isAuthenticated', 'true');
    localStorage.setItem('currentUser', user.name || user.email);
    await addLog({ userIdentity: user.name || user.email, action: 'login', target: 'System', details: `${user.name || user.email} logged in successfully.` });
    toast({ title: "Login Successful", description: `Welcome back, ${user.name || user.email}!` });
  };

  const handleLogout = async () => {
    const userLoggedOut = currentUser || 'User';
    await addLog({ userIdentity: userLoggedOut, action: 'logout', target: 'System', details: `${userLoggedOut} logged out.` });
    
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({ title: "Logout Error", description: error.message, variant: "destructive" });
    } else {
      setIsAuthenticated(false);
      setCurrentUser(null);
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('currentUser');
      toast({ title: "Logout Successful", description: "You have been logged out." });
      navigate('/login'); 
    }
  };
  
  if (loadingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="text-purple-600 text-xl">Loading SKV Company...</div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-slate-100">
      <main className="p-4 sm:p-6 lg:p-8">
        <Routes>
          <Route path="/login" element={isAuthenticated ? <Navigate to="/" /> : <LoginPage onLogin={handleLogin} />} />
          <Route path="/signup" element={isAuthenticated ? <Navigate to="/" /> : <SignUpPage />} />
          <Route path="/forgot-password" element={isAuthenticated ? <Navigate to="/" /> : <ForgotPasswordPage />} />
          
          <Route path="/" element={<ProtectedRoute isAuthenticated={isAuthenticated}><HomePage onLogout={handleLogout} currentUser={currentUser} /></ProtectedRoute>} />
          <Route path="/interns" element={<ProtectedRoute isAuthenticated={isAuthenticated}><InternsPage /></ProtectedRoute>} />
          <Route path="/employees" element={<ProtectedRoute isAuthenticated={isAuthenticated}><EmployeesPage /></ProtectedRoute>} />
          <Route path="/hr" element={<ProtectedRoute isAuthenticated={isAuthenticated}><HRPage /></ProtectedRoute>} />
          <Route path="/projects" element={<ProtectedRoute isAuthenticated={isAuthenticated}><ProjectsPage /></ProtectedRoute>} />
          <Route path="/activity-log" element={<ProtectedRoute isAuthenticated={isAuthenticated}><ActivityLogPage /></ProtectedRoute>} />
          
          <Route path="*" element={<Navigate to={isAuthenticated ? "/" : "/login"} />} />
        </Routes>
      </main>
      <Toaster />
    </div>
  );
}


const AppWrapper = () => (
  <Router>
    <App />
  </Router>
);

export default AppWrapper;