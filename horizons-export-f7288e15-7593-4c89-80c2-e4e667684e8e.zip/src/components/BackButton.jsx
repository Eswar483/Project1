import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

const BackButton = () => {
  const navigate = useNavigate();
  return (
    <Button variant="outline" onClick={() => navigate('/')} className="mb-8 self-start">
      <ArrowLeft className="h-4 w-4 mr-2" />
      Go Back to Home
    </Button>
  );
};
export default BackButton;