
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { LogOut, Bell } from 'lucide-react';
import { motion } from 'framer-motion';

const Navbar = ({ navItems, onLogout }) => {
  const navigate = useNavigate();

  const handleLogoutClick = () => {
    onLogout();
    navigate('/login');
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 120, damping: 20 }}
      className="navbar-custom"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <NavLink to="/" className="navbar-brand-custom">
            SKV Dashboard
          </NavLink>
          <div className="hidden md:flex items-center space-x-2">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `nav-link-custom ${isActive ? 'nav-item-active' : 'nav-item-inactive'}`
                }
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </NavLink>
            ))}
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="text-slate-600 hover:bg-slate-200">
            <Bell className="h-5 w-5" />
          </Button>
           <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
            O
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogoutClick}
            className="logout-button-custom"
            aria-label="Logout"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navbar;
