import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { FolderKanban, Users, UserCheck, PlusCircle, Trash2, Edit3, Search, CalendarDays, CheckSquare, AlertTriangle } from 'lucide-react';
import BackButton from '@/components/BackButton';
import { supabase } from '@/lib/supabaseClient';
import { addLog } from '@/lib/logger';

const ProjectCard = ({ project, onDelete, onEdit, onToggleStatus }) => {

  const getStatusColor = (status) => {
    if (status === 'Completed') return 'text-green-600 border-green-500 bg-green-50';
    if (status === 'In Progress') return 'text-yellow-600 border-yellow-500 bg-yellow-50';
    if (status === 'Pending') return 'text-orange-600 border-orange-500 bg-orange-50';
    if (status === 'On Hold') return 'text-red-600 border-red-500 bg-red-50';
    return 'text-slate-500 border-slate-400 bg-slate-50';
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="card-custom p-5 flex flex-col justify-between"
    >
      <div>
        <div className="flex justify-between items-start mb-3">
          <h3 className="card-title-custom">{project.name}</h3>
          <span className={`px-2 py-1 text-xs font-semibold rounded-none border ${getStatusColor(project.status)}`}>
            {project.status}
          </span>
        </div>
        <p className="card-text-custom mb-3 line-clamp-3 text-sm">{project.description}</p>
        <div className="text-sm space-y-1 mb-4">
          <p className="card-text-custom flex items-center"><Users className="w-4 h-4 mr-2 card-icon-custom" /> Team Members: {project.team_members?.join(', ') || 'N/A'}</p>
          <p className="card-text-custom flex items-center"><Users className="w-4 h-4 mr-2 card-icon-custom" /> Interns: {project.interns?.join(', ') || 'N/A'}</p>
          <p className="card-text-custom flex items-center"><UserCheck className="w-4 h-4 mr-2 card-icon-custom" /> Supervisor: {project.supervisor || 'N/A'}</p>
          {project.deadline && <p className="card-text-custom flex items-center"><CalendarDays className="w-4 h-4 mr-2 card-icon-custom" /> Deadline: {new Date(project.deadline).toLocaleDateString()}</p>}
        </div>
      </div>
      <div className="mt-auto flex flex-col sm:flex-row justify-between items-center gap-2">
        <Button 
          variant={project.status === 'Completed' ? "secondary" : "default"} 
          size="sm" 
          onClick={() => onToggleStatus(project.id, project.status)}
          className={`w-full sm:w-auto ${project.status === 'Completed' ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' : 'bg-green-500 hover:bg-green-600 text-white'}`}
        >
          <CheckSquare className="w-4 h-4 mr-1" /> {project.status === 'Completed' ? 'Re-open' : 'Mark Done'}
        </Button>
        <div className="flex space-x-2 w-full sm:w-auto">
          <Button variant="outline" size="sm" onClick={() => onEdit(project)} className="w-full card-button-outline-custom">
            <Edit3 className="w-4 h-4 mr-1" /> Edit
          </Button>
          <Button variant="destructive" size="sm" onClick={() => onDelete(project.id)} className="w-full">
            <Trash2 className="w-4 h-4 mr-1" /> Delete
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

const ProjectForm = ({ onSubmit, initialData, onCancel, allInterns }) => {
  const [formData, setFormData] = useState({ 
    name: '', description: '', supervisor: '', 
    team_members: [''], interns: [], status: 'Pending', deadline: '' 
  });
  const { toast } = useToast();

  useEffect(() => {
    if (initialData) {
      setFormData({
        ...initialData,
        team_members: initialData.team_members?.length > 0 ? initialData.team_members : [''],
        interns: initialData.interns || [],
        deadline: initialData.deadline ? initialData.deadline.split('T')[0] : '' 
      });
    } else {
      setFormData({ name: '', description: '', supervisor: '', team_members: [''], interns: [], status: 'Pending', deadline: '' });
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleMultiSelectChange = (e, field) => {
    const selectedOptions = Array.from(e.target.selectedOptions, option => option.value);
    if (field === 'interns' && selectedOptions.length > 2) {
        toast({ title: "Intern Limit Exceeded", description: "A project can have a maximum of 2 interns.", variant: "destructive" });
        const validSelections = selectedOptions.slice(0,2);
         Array.from(e.target.options).forEach(option => {
            option.selected = validSelections.includes(option.value);
        });
        setFormData(prev => ({ ...prev, [field]: validSelections }));
        return;
    }
    setFormData(prev => ({ ...prev, [field]: selectedOptions }));
  };
  
  const handleTeamMemberChange = (index, value) => {
    const newTeamMembers = [...formData.team_members];
    newTeamMembers[index] = value;
    setFormData(prev => ({ ...prev, team_members: newTeamMembers }));
  };

  const addTeamMemberField = () => {
    if (formData.team_members.filter(Boolean).length < 5) {
      setFormData(prev => ({ ...prev, team_members: [...prev.team_members, ''] }));
    } else {
      toast({ title: "Limit Reached", description: "Maximum 5 team members allowed.", variant: "destructive" });
    }
  };

  const removeTeamMemberField = (index) => {
    const newTeamMembers = formData.team_members.filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, team_members: newTeamMembers.length > 0 ? newTeamMembers : [''] }));
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.description) {
      toast({ title: "Missing Fields", description: "Project Name and Description are required.", variant: "destructive" });
      return;
    }
     const finalTeamMembers = formData.team_members.filter(member => member.trim() !== '');
    if (finalTeamMembers.length > 5) {
        toast({ title: "Team Member Limit Exceeded", description: "Please list a maximum of 5 team members.", variant: "destructive" });
        return;
    }
    onSubmit({ ...formData, id: initialData?.id, team_members: finalTeamMembers }); 
    if (!initialData) setFormData({ name: '', description: '', supervisor: '', team_members: [''], interns: [], status: 'Pending', deadline: '' }); 
  };

  return (
    <motion.form 
      onSubmit={handleSubmit} 
      className="space-y-4 p-6 bg-white rounded-none shadow-sm mb-8 border border-slate-200"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h2 className="text-xl font-semibold text-slate-800 mb-4">{initialData ? 'Edit Project' : 'Add New Project'}</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="projectName" className="text-slate-700">Project Name</Label>
          <Input id="projectName" name="name" value={formData.name} onChange={handleChange} placeholder="Project Alpha" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="projectSupervisor" className="text-slate-700">Supervisor</Label>
          <Input id="projectSupervisor" name="supervisor" value={formData.supervisor} onChange={handleChange} placeholder="Dr. Smith" className="input-custom mt-1" />
        </div>
      </div>

      <div>
        <Label htmlFor="projectDescription" className="text-slate-700">Description</Label>
        <textarea id="projectDescription" name="description" value={formData.description} onChange={handleChange} placeholder="Detailed project description..." rows="3" className="input-custom w-full mt-1"></textarea>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="projectDeadline" className="text-slate-700">Deadline</Label>
          <Input id="projectDeadline" name="deadline" type="date" value={formData.deadline} onChange={handleChange} className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="projectStatus" className="text-slate-700">Status</Label>
          <select id="projectStatus" name="status" value={formData.status} onChange={handleChange} className="input-custom w-full mt-1">
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
            <option value="On Hold">On Hold</option>
          </select>
        </div>
      </div>
      
      <div>
        <Label className="text-slate-700">Team Members (Max 5)</Label>
        {formData.team_members.map((member, index) => (
          <div key={index} className="flex items-center space-x-2 mt-1">
            <Input 
              value={member} 
              onChange={(e) => handleTeamMemberChange(index, e.target.value)} 
              placeholder={`Team Member ${index + 1}`} 
              className="input-custom flex-grow"
            />
            <Button type="button" variant="destructive" size="icon" onClick={() => removeTeamMemberField(index)} className="p-2 h-10 w-10"><Trash2 className="w-4 h-4"/></Button>
          </div>
        ))}
        {formData.team_members.filter(Boolean).length < 5 && (
          <Button type="button" variant="outline" size="sm" onClick={addTeamMemberField} className="mt-2 card-button-outline-custom">
            <PlusCircle className="w-4 h-4 mr-1"/> Add Member
          </Button>
        )}
      </div>

      <div>
        <Label htmlFor="projectInterns" className="text-slate-700">Assign Interns (Max 2)</Label>
        <select 
          id="projectInterns" 
          name="interns" 
          multiple 
          value={formData.interns} 
          onChange={(e) => handleMultiSelectChange(e, 'interns')} 
          className="input-custom w-full mt-1 h-24"
        >
          {allInterns.map(intern => (
            <option key={intern.id} value={intern.name}>{intern.name}</option>
          ))}
        </select>
        <p className="text-xs text-slate-500 mt-1">Hold Ctrl/Cmd to select multiple. Max 2 interns.</p>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        {onCancel && <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" className="btn-primary-custom">{initialData ? 'Save Changes' : 'Add Project'}</Button>
      </div>
    </motion.form>
  );
};


const ProjectsPage = () => {
  const [projects, setProjects] = useState([]);
  const [allInterns, setAllInterns] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const currentUser = localStorage.getItem('currentUser') || 'System';

  useEffect(() => {
    fetchProjects();
    fetchInternNames();
  }, []);

  const fetchProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('projects_skv').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching projects", description: error.message, variant: "destructive" });
      setProjects([]);
    } else {
      setProjects(data);
    }
    setLoading(false);
  };

  const fetchInternNames = async () => {
    const { data, error } = await supabase.from('interns_skv').select('id, name');
    if (error) {
      toast({ title: "Error fetching intern names", description: error.message, variant: "destructive" });
      setAllInterns([]);
    } else {
      setAllInterns(data);
    }
  };

  const handleAddProject = async (projectData) => {
    const { error } = await supabase.from('projects_skv').insert([projectData]);
    if (error) {
      toast({ title: "Error adding project", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Project Added", description: `${projectData.name} has been successfully added.` });
      await addLog({ userIdentity: currentUser, action: 'create', target: 'Project', details: `Added project: ${projectData.name}` });
      fetchProjects();
      setShowForm(false);
    }
  };

  const handleEditProject = async (updatedProject) => {
    const { error } = await supabase.from('projects_skv').update(updatedProject).eq('id', updatedProject.id);
    if (error) {
      toast({ title: "Error updating project", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Project Updated", description: `${updatedProject.name}'s details have been updated.` });
      await addLog({ userIdentity: currentUser, action: 'update', target: 'Project', details: `Updated project: ${updatedProject.name}` });
      fetchProjects();
      setEditingProject(null);
      setShowForm(false);
    }
  };
  
  const handleDeleteProject = async (id) => {
    const projectToDelete = projects.find(p => p.id === id);
    const { error } = await supabase.from('projects_skv').delete().eq('id', id);
    if (error) {
      toast({ title: "Error deleting project", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Project Deleted", description: `${projectToDelete?.name || 'Project'} has been deleted.`, variant: "destructive" });
      await addLog({ userIdentity: currentUser, action: 'delete', target: 'Project', details: `Deleted project: ${projectToDelete?.name}` });
      fetchProjects();
    }
  };

  const handleToggleStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === 'Completed' ? 'In Progress' : 'Completed';
    const { error } = await supabase.from('projects_skv').update({ status: newStatus }).eq('id', id);
    
    if (error) {
      toast({ title: "Error updating status", description: error.message, variant: "destructive" });
    } else {
      const project = projects.find(p => p.id === id);
      toast({ title: "Status Updated", description: `${project?.name || 'Project'} marked as ${newStatus}.` });
      await addLog({ userIdentity: currentUser, action: 'update_status', target: 'Project', details: `Project ${project?.name} status changed to ${newStatus}` });
      fetchProjects();
    }
  };

  const startEdit = (project) => {
    setEditingProject(project);
    setShowForm(true);
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingProject(null);
  }

  const filteredProjects = projects.filter(project =>
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (project.supervisor && project.supervisor.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="animate-fade-in-up space-y-8 flex flex-col">
      <BackButton />
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-center gap-4"
      >
        <h1 className="page-title-custom">Project Management</h1>
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search projects..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-custom pl-10 w-full sm:w-64"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
          </div>
          <Button onClick={() => { setShowForm(true); setEditingProject(null); }} className="btn-primary-custom">
            <PlusCircle className="w-5 h-5 mr-2" /> Add Project
          </Button>
        </div>
      </motion.div>

      {showForm && (
        <ProjectForm 
          onSubmit={editingProject ? handleEditProject : handleAddProject} 
          initialData={editingProject}
          onCancel={cancelForm}
          allInterns={allInterns}
        />
      )}
      {loading ? (
        <div className="text-center text-slate-500 py-10">Loading projects...</div>
      ) : filteredProjects.length > 0 ? (
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredProjects.map(project => (
            <ProjectCard 
              key={project.id} 
              project={project} 
              onDelete={handleDeleteProject} 
              onEdit={startEdit}
              onToggleStatus={handleToggleStatus}
            />
          ))}
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-slate-500 text-xl py-10 rounded-none bg-white border border-dashed"
        >
          <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
          <p>No projects found. {searchTerm && "Try a different search term or "}add a new project to get started!</p>
        </motion.div>
      )}
    </div>
  );
};

export default ProjectsPage;