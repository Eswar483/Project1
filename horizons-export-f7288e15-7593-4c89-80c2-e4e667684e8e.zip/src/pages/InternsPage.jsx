import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { UserPlus, Trash2, Edit3, Search, UploadCloud, Users, Briefcase, Brain } from 'lucide-react';
import BackButton from '@/components/BackButton';
import { supabase } from '@/lib/supabaseClient';
import { addLog } from '@/lib/logger';

const InternCard = ({ intern, onDelete, onEdit }) => (
  <motion.div 
    layout
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 0.8 }}
    transition={{ type: 'spring', stiffness: 260, damping: 20 }}
    className="card-custom p-5"
  >
    <div className="flex items-center space-x-4 mb-4">
      {intern.profile_pic ? (
        <img src={intern.profile_pic} alt={intern.name} className="w-16 h-16 rounded-none object-cover border-2 card-profile-pic-border" />
      ) : (
        <div className="w-16 h-16 rounded-none card-profile-pic-placeholder flex items-center justify-center text-2xl font-bold">
          {intern.name.charAt(0)}
        </div>
      )}
      <div>
        <h3 className="card-title-custom">{intern.name}</h3>
        <p className="card-subtitle-custom">{intern.email}</p>
      </div>
    </div>
    <div className="space-y-2 text-sm">
      <p className="card-text-custom flex items-center"><Briefcase className="w-4 h-4 mr-2 card-icon-custom" /> Company: {intern.company}</p>
      <p className="card-text-custom flex items-center"><Brain className="w-4 h-4 mr-2 card-icon-custom" /> Skills: {intern.skills}</p>
      <p className="card-text-custom flex items-center"><Users className="w-4 h-4 mr-2 card-icon-custom" /> Team: {intern.team || 'N/A'}</p>
    </div>
    <div className="mt-4 flex justify-end space-x-2">
      <Button variant="outline" size="sm" onClick={() => onEdit(intern)} className="card-button-outline-custom">
        <Edit3 className="w-4 h-4 mr-1" /> Edit
      </Button>
      <Button variant="destructive" size="sm" onClick={() => onDelete(intern.id)}>
        <Trash2 className="w-4 h-4 mr-1" /> Delete
      </Button>
    </div>
  </motion.div>
);

const InternForm = ({ onSubmit, initialData, onCancel }) => {
  const [formData, setFormData] = useState({
    name: '', email: '', company: '', skills: '', team: '', profile_pic: null
  });
  const [profilePicPreview, setProfilePicPreview] = useState(null);
  const { toast } = useToast();
  
  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || '',
        email: initialData.email || '',
        company: initialData.company || '',
        skills: initialData.skills || '',
        team: initialData.team || '',
        profile_pic: initialData.profile_pic || null,
      });
      setProfilePicPreview(initialData.profile_pic || null);
    } else {
       setFormData({ name: '', email: '', company: '', skills: '', team: '', profile_pic: null });
       setProfilePicPreview(null);
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { 
        toast({ title: "File too large", description: "Profile picture must be less than 2MB.", variant: "destructive" });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, profile_pic: reader.result }));
        setProfilePicPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.company || !formData.skills) {
      toast({ title: "Missing Fields", description: "Please fill in all required fields.", variant: "destructive" });
      return;
    }
    onSubmit({ ...formData, id: initialData?.id });
    if (!initialData) { 
      setFormData({ name: '', email: '', company: '', skills: '', team: '', profile_pic: null });
      setProfilePicPreview(null);
    }
  };

  return (
    <motion.form 
      onSubmit={handleSubmit} 
      className="space-y-4 p-6 bg-white shadow-sm mb-8 border border-slate-200"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h2 className="text-xl font-semibold text-slate-800 mb-4">{initialData ? 'Edit Intern' : 'Add New Intern'}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name" className="text-slate-700">Full Name</Label>
          <Input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="John Doe" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="email" className="text-slate-700">Email</Label>
          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} placeholder="john.doe@example.com" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="company" className="text-slate-700">Company</Label>
          <Input id="company" name="company" value={formData.company} onChange={handleChange} placeholder="SKV Company" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="skills" className="text-slate-700">Skills (comma-separated)</Label>
          <Input id="skills" name="skills" value={formData.skills} onChange={handleChange} placeholder="React, Node.js, TailwindCSS" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="team" className="text-slate-700">Team (Optional)</Label>
          <Input id="team" name="team" value={formData.team} onChange={handleChange} placeholder="Alpha Team" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="profilePic" className="text-slate-700">Profile Picture</Label>
          <div className="mt-1 flex items-center space-x-3">
            {profilePicPreview && <img src={profilePicPreview} alt="Preview" className="w-16 h-16 rounded-none object-cover" />}
            <label htmlFor="profilePic" className="cursor-pointer bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 inline-flex items-center">
              <UploadCloud className="w-4 h-4 mr-2" />
              <span>{profilePicPreview ? 'Change' : 'Upload'}</span>
            </label>
            <Input id="profilePic" type="file" onChange={handleFileChange} className="hidden" accept="image/png, image/jpeg, image/gif" />
          </div>
        </div>
      </div>
      <div className="flex justify-end space-x-3 pt-4">
        {onCancel && <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" className="btn-primary-custom">{initialData ? 'Save Changes' : 'Add Intern'}</Button>
      </div>
    </motion.form>
  );
};


const InternsPage = () => {
  const [interns, setInterns] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingIntern, setEditingIntern] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const currentUser = localStorage.getItem('currentUser') || 'System';

  useEffect(() => {
    fetchInterns();
  }, []);

  const fetchInterns = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('interns_skv').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching interns", description: error.message, variant: "destructive" });
      setInterns([]);
    } else {
      setInterns(data);
    }
    setLoading(false);
  };

  const handleAddIntern = async (internData) => {
    const { error } = await supabase.from('interns_skv').insert([internData]);
    if (error) {
      toast({ title: "Error adding intern", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Intern Added", description: `${internData.name} has been successfully added.` });
      await addLog({ userIdentity: currentUser, action: 'create', target: 'Intern', details: `Added intern: ${internData.name}` });
      fetchInterns();
      setShowForm(false);
    }
  };

  const handleEditIntern = async (updatedIntern) => {
    const { error } = await supabase.from('interns_skv').update(updatedIntern).eq('id', updatedIntern.id);
    if (error) {
      toast({ title: "Error updating intern", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Intern Updated", description: `${updatedIntern.name}'s details have been updated.` });
      await addLog({ userIdentity: currentUser, action: 'update', target: 'Intern', details: `Updated intern: ${updatedIntern.name}` });
      fetchInterns();
      setEditingIntern(null);
      setShowForm(false);
    }
  };
  
  const handleDeleteIntern = async (id) => {
    const internToDelete = interns.find(intern => intern.id === id);
    const { error } = await supabase.from('interns_skv').delete().eq('id', id);
    if (error) {
      toast({ title: "Error deleting intern", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Intern Deleted", description: `${internToDelete?.name || 'Intern'} has been deleted.`, variant: "destructive" });
      await addLog({ userIdentity: currentUser, action: 'delete', target: 'Intern', details: `Deleted intern: ${internToDelete?.name}` });
      fetchInterns();
    }
  };

  const startEdit = (intern) => {
    setEditingIntern(intern);
    setShowForm(true);
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingIntern(null);
  }

  const filteredInterns = interns.filter(intern =>
    intern.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    intern.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    intern.skills.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="animate-fade-in-up space-y-8 flex flex-col">
      <BackButton />
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-center gap-4"
      >
        <h1 className="page-title-custom">Intern Management</h1>
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search interns..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-custom pl-10 w-full sm:w-64"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
          </div>
          <Button onClick={() => { setShowForm(true); setEditingIntern(null); }} className="btn-primary-custom">
            <UserPlus className="w-5 h-5 mr-2" /> Add Intern
          </Button>
        </div>
      </motion.div>

      {showForm && (
        <InternForm 
          onSubmit={editingIntern ? handleEditIntern : handleAddIntern} 
          initialData={editingIntern}
          onCancel={cancelForm}
        />
      )}
      {loading ? (
         <div className="text-center text-slate-500 py-10">Loading interns...</div>
      ) : filteredInterns.length > 0 ? (
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredInterns.map(intern => (
            <InternCard key={intern.id} intern={intern} onDelete={handleDeleteIntern} onEdit={startEdit} />
          ))}
        </motion.div>
      ) : (
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-slate-500 text-xl py-10"
        >
          No interns found. {searchTerm && "Try a different search term or "}add a new intern to get started!
        </motion.p>
      )}
    </div>
  );
};

export default InternsPage;