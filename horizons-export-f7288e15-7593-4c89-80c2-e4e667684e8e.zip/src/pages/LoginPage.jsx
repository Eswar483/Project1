import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input'; 
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Mail, Lock, LogIn as LogInIcon, Building } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

const LoginPage = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const { data: { user: authUser, session }, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (signInError) {
      toast({
        title: 'Login Failed',
        description: signInError.message || 'Invalid email or password.',
        variant: 'destructive',
      });
      return;
    }

    if (authUser && session) {
      const { data: userData, error: userError } = await supabase
        .from('users_skv')
        .select('name, email')
        .eq('email', email)
        .single();

      if (userError && !userData) {
         toast({
          title: 'Login Failed',
          description: 'Could not retrieve user details. Please try again.',
          variant: 'destructive',
        });
        await supabase.auth.signOut(); 
        return;
      }
      
      onLogin(userData || { email: authUser.email, name: authUser.user_metadata?.name || authUser.email });
      navigate('/');
    } else {
       toast({
        title: 'Login Failed',
        description: 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex bg-white">
      <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto w-full max-w-sm lg:w-96"
        >
          <div>
            <div className="flex items-center text-purple-600">
                <Building className="h-8 w-8 mr-2" />
                <h2 className="text-3xl font-bold">SKV Company</h2>
            </div>
            <h2 className="mt-6 text-3xl font-extrabold text-slate-900">
              Sign in to your account
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Welcome back! Please enter your details.
            </p>
          </div>

          <div className="mt-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="email" className="login-label-custom">Email address</Label>
                <div className="mt-1">
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input-custom"
                    placeholder="you@example.com"
                  />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="password"className="login-label-custom">Password</Label>
                  <div className="text-sm">
                    <Link to="/forgot-password" className="page-link-custom">
                      Forgot your password?
                    </Link>
                  </div>
                </div>
                <div className="mt-1">
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input-custom"
                    placeholder="••••••••"
                  />
                </div>
              </div>
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button type="submit" className="w-full btn-primary-custom flex items-center justify-center space-x-2 py-3 text-base">
                  <LogInIcon className="h-5 w-5" />
                  <span>Sign In</span>
                </Button>
              </motion.div>
            </form>
             <p className="mt-6 text-center text-sm text-slate-600">
                Don't have an account?{' '}
                <Link to="/signup" className="page-link-custom">
                    Sign Up
                </Link>
             </p>
          </div>
        </motion.div>
      </div>
       <div className="hidden lg:block relative w-0 flex-1">
        <img  className="absolute inset-0 h-full w-full object-cover" alt="Modern office space" src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d" />
      </div>
    </div>
  );
};

export default LoginPage;