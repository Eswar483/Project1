
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Users, Briefcase, FolderKanban, UserCog, History, ArrowRight, LogOut, Hand } from 'lucide-react';
import { Link } from 'react-router-dom';

const navItems = [
    { path: '/interns', label: 'Interns', icon: Users, description: "Manage all company interns, view profiles, and track progress.", color: "from-blue-500 to-blue-600", shadowColor: "shadow-blue-500/50" },
    { path: '/employees', label: 'Employees', icon: UserCog, description: "Access the directory of all full-time employees and their roles.", color: "from-green-500 to-green-600", shadowColor: "shadow-green-500/50" },
    { path: '/hr', label: 'HR', icon: Briefcase, description: "Oversee HR staff, policies, and official company documents.", color: "from-red-500 to-red-600", shadowColor: "shadow-red-500/50" },
    { path: '/projects', label: 'Projects', icon: FolderKanban, description: "Monitor active projects, team assignments, and deadlines.", color: "from-yellow-500 to-yellow-600", shadowColor: "shadow-yellow-500/50" },
    { path: '/activity-log', label: 'Activity Log', icon: History, description: "Review a complete log of all administrative actions.", color: "from-slate-500 to-slate-600", shadowColor: "shadow-slate-500/50" },
];

const cardVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
  hover: { y: -10, scale: 1.03, transition: { type: 'spring', stiffness: 300, damping: 15 } }
};

const NavCard = ({ item, index }) => (
  <motion.div 
    variants={cardVariants}
    initial="initial"
    animate="animate"
    whileHover="hover"
    custom={index}
    transition={{ delay: index * 0.1 }}
    className={`bg-white shadow-lg hover:shadow-xl ${item.shadowColor} rounded-lg overflow-hidden border border-slate-200`}
  >
    <Link to={item.path} className="block p-6 h-full flex flex-col">
      <div className="flex items-center mb-4">
        <div className={`p-3 mr-4 bg-gradient-to-br ${item.color} text-white rounded-lg shadow-md`}>
            <item.icon className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">{item.label}</h2>
      </div>
      <p className="text-slate-600 text-sm mb-4 flex-grow">{item.description}</p>
      <div className="flex items-center text-purple-600 font-semibold text-sm mt-auto group">
        Go to {item.label} <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform duration-200" />
      </div>
    </Link>
  </motion.div>
);

const HomePage = ({ onLogout, currentUser }) => {
  return (
    <div className="animate-fade-in-up space-y-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col sm:flex-row justify-between items-center p-6 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg shadow-xl text-white"
        >
            <div className="flex items-center">
                <Hand className="w-10 h-10 mr-3 text-yellow-300 transform rotate-[-20deg]" />
                <div>
                    <h1 className="text-3xl font-bold">Welcome back, {currentUser}!</h1>
                    <p className="text-purple-200">Here's your SKV Company dashboard.</p>
                </div>
            </div>
            <Button onClick={onLogout} variant="outline" className="mt-4 sm:mt-0 bg-white/20 hover:bg-white/30 text-white border-white/50 hover:border-white flex items-center rounded-md">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
            </Button>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {navItems.map((item, index) => (
                <NavCard key={item.path} item={item} index={index} />
            ))}
        </div>
    </div>
  );
};

export default HomePage;