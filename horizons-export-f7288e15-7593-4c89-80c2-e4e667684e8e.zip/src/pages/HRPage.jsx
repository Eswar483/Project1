import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Briefcase, PlusCircle, Trash2, Edit3, Search, Building2 } from 'lucide-react';
import BackButton from '@/components/BackButton';
import { supabase } from '@/lib/supabaseClient';
import { addLog } from '@/lib/logger';

const HRItemCard = ({ item, onDelete, onEdit, type }) => (
  <motion.div
    layout
    initial={{ opacity: 0, scale: 0.9 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 0.9 }}
    className="card-custom p-5"
  >
    <div className="flex items-start justify-between">
      <div>
        <h3 className="card-title-custom mb-1">{item.title || item.name}</h3>
        {type === 'employee' && <p className="card-subtitle-custom">{item.position}</p>}
        {type === 'policy' && <p className="text-sm text-slate-500">Version: {item.version}</p>}
      </div>
      {type === 'employee' && item.profile_pic ? (
         <img src={item.profile_pic} alt={item.name} className="w-12 h-12 rounded-none object-cover border-2 card-profile-pic-border" />
      ) : type === 'employee' ? (
        <div className="w-12 h-12 rounded-none card-profile-pic-placeholder flex items-center justify-center text-xl font-bold">
          {(item.name || 'N').charAt(0)}
        </div>
      ) : null}
    </div>
    <p className="card-text-custom mt-2 text-sm leading-relaxed line-clamp-3">{item.description || 'No description available.'}</p>
    <div className="mt-4 flex justify-end space-x-2">
      <Button variant="outline" size="sm" onClick={() => onEdit(item)} className="card-button-outline-custom">
        <Edit3 className="w-4 h-4 mr-1" /> Edit
      </Button>
      <Button variant="destructive" size="sm" onClick={() => onDelete(item.id)}>
        <Trash2 className="w-4 h-4 mr-1" /> Delete
      </Button>
    </div>
  </motion.div>
);

const HRForm = ({ onSubmit, initialData, onCancel, type }) => {
  const [formData, setFormData] = useState({});
  const [profilePicPreviewHr, setProfilePicPreviewHr] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    if(initialData) {
        setFormData(initialData);
        if(initialData.profile_pic) {
            setProfilePicPreviewHr(initialData.profile_pic);
        } else {
            setProfilePicPreviewHr(null);
        }
    } else {
        setFormData(type === 'employee' ? {name: '', position: '', department: '', profile_pic: null} : {title: '', version: '', description: ''});
        setProfilePicPreviewHr(null);
    }
  }, [initialData, type]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, profile_pic: reader.result }));
        setProfilePicPreviewHr(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredField = type === 'employee' ? 'name' : 'title';
    if (!formData[requiredField]) {
      toast({ title: "Missing Field", description: `Please fill in the ${requiredField}.`, variant: "destructive" });
      return;
    }
    onSubmit({ ...formData, id: initialData?.id });
    if (!initialData) {
        setFormData(type === 'employee' ? {name: '', position: '', department: '', profile_pic: null} : {title: '', version: '', description: ''});
        setProfilePicPreviewHr(null);
    }
  };

  return (
    <motion.form 
      onSubmit={handleSubmit} 
      className="space-y-4 p-6 bg-white rounded-none shadow-sm mb-8 border border-slate-200"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h2 className="text-xl font-semibold text-slate-800 mb-4">
        {initialData ? 'Edit' : 'Add New'} {type === 'employee' ? 'HR Employee' : 'Policy/Document'}
      </h2>
      {type === 'employee' ? (
        <>
          <Input name="name" value={formData.name || ''} onChange={handleChange} placeholder="Employee Name" className="input-custom" />
          <Input name="position" value={formData.position || ''} onChange={handleChange} placeholder="Position (e.g., HR Manager)" className="input-custom" />
          <Input name="department" value={formData.department || ''} onChange={handleChange} placeholder="Department" className="input-custom" />
          <div>
            <Label htmlFor="profilePicHR" className="text-slate-700">Profile Picture</Label>
            {profilePicPreviewHr && <img src={profilePicPreviewHr} alt="Preview" className="w-16 h-16 rounded-none object-cover my-2" />}
            <Input id="profilePicHR" name="profile_pic" type="file" onChange={handleFileChange} className="input-custom mt-1" accept="image/*" />
          </div>
        </>
      ) : (
        <>
          <Input name="title" value={formData.title || ''} onChange={handleChange} placeholder="Policy Title or Document Name" className="input-custom" />
          <Input name="version" value={formData.version || ''} onChange={handleChange} placeholder="Version (e.g., 1.0)" className="input-custom" />
          <textarea name="description" value={formData.description || ''} onChange={handleChange} placeholder="Brief description..." rows="3" className="input-custom w-full"></textarea>
        </>
      )}
      <div className="flex justify-end space-x-3 pt-4">
        {onCancel && <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" className="btn-primary-custom">{initialData ? 'Save Changes' : `Add ${type}`}</Button>
      </div>
    </motion.form>
  );
};

const HRPage = () => {
  const [hrEmployees, setHrEmployees] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formType, setFormType] = useState('employee'); 
  const [loadingEmployees, setLoadingEmployees] = useState(true);
  const [loadingPolicies, setLoadingPolicies] = useState(true);
  const { toast } = useToast();
  const currentUser = localStorage.getItem('currentUser') || 'System';

  useEffect(() => {
    fetchHrEmployees();
    fetchPolicies();
  }, []);

  const fetchHrEmployees = async () => {
    setLoadingEmployees(true);
    const { data, error } = await supabase.from('hr_employees_skv').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching HR employees", description: error.message, variant: "destructive" });
      setHrEmployees([]);
    } else {
      setHrEmployees(data);
    }
    setLoadingEmployees(false);
  };

  const fetchPolicies = async () => {
    setLoadingPolicies(true);
    const { data, error } = await supabase.from('hr_policies_skv').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching policies", description: error.message, variant: "destructive" });
      setPolicies([]);
    } else {
      setPolicies(data);
    }
    setLoadingPolicies(false);
  };

  const handleAddItem = async (itemData) => {
    const table = formType === 'employee' ? 'hr_employees_skv' : 'hr_policies_skv';
    const { error } = await supabase.from(table).insert([itemData]);
    if (error) {
      toast({ title: `Error adding ${formType}`, description: error.message, variant: "destructive" });
    } else {
      toast({ title: `${formType.charAt(0).toUpperCase() + formType.slice(1)} Added`, description: `${itemData.name || itemData.title} added.` });
      await addLog({ userIdentity: currentUser, action: 'create', target: `HR ${formType}`, details: `Added ${formType}: ${itemData.name || itemData.title}` });
      formType === 'employee' ? fetchHrEmployees() : fetchPolicies();
      setShowForm(false); setEditingItem(null);
    }
  };

  const handleEditItem = async (updatedItem) => {
    const table = formType === 'employee' ? 'hr_employees_skv' : 'hr_policies_skv';
    const { error } = await supabase.from(table).update(updatedItem).eq('id', updatedItem.id);
    if (error) {
      toast({ title: `Error updating ${formType}`, description: error.message, variant: "destructive" });
    } else {
      toast({ title: `${formType.charAt(0).toUpperCase() + formType.slice(1)} Updated`, description: `${updatedItem.name || updatedItem.title} updated.` });
      await addLog({ userIdentity: currentUser, action: 'update', target: `HR ${formType}`, details: `Updated ${formType}: ${updatedItem.name || updatedItem.title}` });
      formType === 'employee' ? fetchHrEmployees() : fetchPolicies();
      setShowForm(false); setEditingItem(null);
    }
  };

  const handleDeleteItem = async (id, type) => {
    const table = type === 'employee' ? 'hr_employees_skv' : 'hr_policies_skv';
    const itemToDelete = type === 'employee' ? hrEmployees.find(item => item.id === id) : policies.find(item => item.id === id);
    const { error } = await supabase.from(table).delete().eq('id', id);
    if (error) {
      toast({ title: `Error deleting ${type}`, description: error.message, variant: "destructive" });
    } else {
      toast({ title: `${type.charAt(0).toUpperCase() + type.slice(1)} Deleted`, description: `${itemToDelete?.name || itemToDelete?.title || 'Item'} deleted.`, variant: "destructive" });
      await addLog({ userIdentity: currentUser, action: 'delete', target: `HR ${type}`, details: `Deleted ${type}: ${itemToDelete?.name || itemToDelete?.title}` });
      type === 'employee' ? fetchHrEmployees() : fetchPolicies();
    }
  };

  const openForm = (type, item = null) => {
    setFormType(type);
    setEditingItem(item);
    setShowForm(true);
  };
  
  const companyDetails = {
    name: "SKV Company",
    address: "123 Innovation Drive, Tech City, TC 54321",
    contact: "hr@skvcompany.com | (555) 123-4567",
    employeeCount: hrEmployees.length, 
  };

  const filteredHrEmployees = hrEmployees.filter(e => e.name?.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredPolicies = policies.filter(p => p.title?.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="animate-fade-in-up space-y-8 flex flex-col">
      <BackButton />
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-center gap-4"
      >
        <h1 className="page-title-custom">HR & Company Management</h1>
        <div className="relative">
          <Input
            type="text"
            placeholder="Search HR staff or policies..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-custom pl-10 w-full sm:w-72"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
        </div>
      </motion.div>

      {showForm && (
        <HRForm 
          onSubmit={editingItem ? handleEditItem : handleAddItem} 
          initialData={editingItem}
          onCancel={() => { setShowForm(false); setEditingItem(null); }}
          type={formType}
        />
      )}

      <motion.section 
        className="mb-8 card-custom p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <div className="flex items-center mb-4">
          <Building2 className="w-10 h-10 text-purple-500 mr-4" />
          <div>
            <h2 className="text-2xl font-semibold text-slate-800">{companyDetails.name}</h2>
            <p className="text-sm text-slate-600">{companyDetails.address}</p>
            <p className="text-sm text-slate-600">{companyDetails.contact}</p>
          </div>
        </div>
        <p className="text-slate-700">Total HR Staff: <span className="font-bold text-purple-600">{companyDetails.employeeCount}</span></p>
      </motion.section>

      <Section title="HR Staff" onAdd={() => openForm('employee')} count={filteredHrEmployees.length} loading={loadingEmployees}>
        {filteredHrEmployees.map(emp => (
          <HRItemCard key={emp.id} item={emp} onDelete={(id) => handleDeleteItem(id, 'employee')} onEdit={(item) => openForm('employee', item)} type="employee" />
        ))}
      </Section>

      <Section title="Policies & Documents" onAdd={() => openForm('policy')} count={filteredPolicies.length} loading={loadingPolicies}>
        {filteredPolicies.map(pol => (
          <HRItemCard key={pol.id} item={pol} onDelete={(id) => handleDeleteItem(id, 'policy')} onEdit={(item) => openForm('policy', item)} type="policy" />
        ))}
      </Section>
    </div>
  );
};

const Section = ({ title, onAdd, count, loading, children }) => (
  <motion.section 
    className="space-y-6"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: 0.2 }}
  >
    <div className="flex justify-between items-center">
      <h2 className="text-2xl font-semibold text-slate-800">{title} ({loading ? '...' : count})</h2>
      <Button onClick={onAdd} className="btn-primary-custom">
        <PlusCircle className="w-5 h-5 mr-2" /> Add New
      </Button>
    </div>
    {loading ? (
      <div className="text-center text-slate-500 py-10">Loading...</div>
    ) : count > 0 ? (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {children}
      </div>
    ) : (
      <div className="text-center text-slate-500 text-lg py-10 rounded-none bg-white border border-dashed">
        <p>No items to display. Click "Add New" to get started.</p>
      </div>
    )}
  </motion.section>
);

export default HRPage;