import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { UserPlus, Trash2, Edit3, Search, UploadCloud, UserCog, Mail, Phone } from 'lucide-react';
import BackButton from '@/components/BackButton';
import { supabase } from '@/lib/supabaseClient';
import { addLog } from '@/lib/logger';

const EmployeeCard = ({ employee, onDelete, onEdit }) => (
  <motion.div 
    layout
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 0.8 }}
    transition={{ type: 'spring', stiffness: 260, damping: 20 }}
    className="card-custom p-5"
  >
    <div className="flex items-center space-x-4 mb-4">
      {employee.profile_pic ? (
        <img src={employee.profile_pic} alt={employee.name} className="w-20 h-20 rounded-none object-cover border-2 card-profile-pic-border" />
      ) : (
        <div className="w-20 h-20 rounded-none card-profile-pic-placeholder flex items-center justify-center text-3xl font-bold">
          {employee.name.charAt(0)}
        </div>
      )}
      <div>
        <h3 className="card-title-custom">{employee.name}</h3>
        <p className="card-subtitle-custom">{employee.position}</p>
        <p className="card-muted-text-custom">{employee.department} Department</p>
      </div>
    </div>
    <div className="space-y-1 text-sm mb-4">
      <p className="card-text-custom flex items-center"><Mail className="w-4 h-4 mr-2 card-icon-custom" /> {employee.email}</p>
      <p className="card-text-custom flex items-center"><Phone className="w-4 h-4 mr-2 card-icon-custom" /> {employee.phone || 'N/A'}</p>
    </div>
    <div className="mt-4 flex justify-end space-x-2">
      <Button variant="outline" size="sm" onClick={() => onEdit(employee)} className="card-button-outline-custom">
        <Edit3 className="w-4 h-4 mr-1" /> Edit
      </Button>
      <Button variant="destructive" size="sm" onClick={() => onDelete(employee.id)}>
        <Trash2 className="w-4 h-4 mr-1" /> Delete
      </Button>
    </div>
  </motion.div>
);

const EmployeeForm = ({ onSubmit, initialData, onCancel }) => {
  const [formData, setFormData] = useState({ name: '', email: '', position: '', department: '', phone: '', profile_pic: null });
  const [profilePicPreview, setProfilePicPreview] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    if (initialData) {
        setFormData({
            name: initialData.name || '',
            email: initialData.email || '',
            position: initialData.position || '',
            department: initialData.department || '',
            phone: initialData.phone || '',
            profile_pic: initialData.profile_pic || null
        });
        setProfilePicPreview(initialData.profile_pic);
    } else {
        setFormData({ name: '', email: '', position: '', department: '', phone: '', profile_pic: null });
        setProfilePicPreview(null);
    }
  }, [initialData]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { 
        toast({ title: "File too large", description: "Profile picture must be less than 2MB.", variant: "destructive" });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({...prev, profile_pic: reader.result}));
        setProfilePicPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.position || !formData.department) {
      toast({ title: "Missing Fields", description: "Please fill in all required fields (Name, Email, Position, Department).", variant: "destructive" });
      return;
    }
    onSubmit({ ...formData, id: initialData?.id });
    if (!initialData) { 
      setFormData({ name: '', email: '', position: '', department: '', phone: '', profile_pic: null });
      setProfilePicPreview(null);
    }
  };

  return (
    <motion.form 
      onSubmit={handleSubmit} 
      className="space-y-4 p-6 bg-white rounded-none shadow-sm mb-8 border border-slate-200"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h2 className="text-xl font-semibold text-slate-800 mb-4">{initialData ? 'Edit Employee' : 'Add New Employee'}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="empName" className="text-slate-700">Full Name</Label>
          <Input id="empName" name="name" value={formData.name} onChange={handleChange} placeholder="John Doe" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="empEmail" className="text-slate-700">Email</Label>
          <Input id="empEmail" name="email" type="email" value={formData.email} onChange={handleChange} placeholder="john.doe@example.com" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="empPosition" className="text-slate-700">Position</Label>
          <Input id="empPosition" name="position" value={formData.position} onChange={handleChange} placeholder="Software Engineer" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="empDepartment" className="text-slate-700">Department</Label>
          <Input id="empDepartment" name="department" value={formData.department} onChange={handleChange} placeholder="Technology" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="empPhone" className="text-slate-700">Phone (Optional)</Label>
          <Input id="empPhone" name="phone" type="tel" value={formData.phone} onChange={handleChange} placeholder="555-123-4567" className="input-custom mt-1" />
        </div>
        <div>
          <Label htmlFor="empProfilePic" className="text-slate-700">Profile Picture</Label>
          <div className="mt-1 flex items-center space-x-3">
            {profilePicPreview && <img src={profilePicPreview} alt="Preview" className="w-16 h-16 rounded-none object-cover" />}
            <label htmlFor="empProfilePic" className="cursor-pointer bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-4 rounded-none inline-flex items-center">
              <UploadCloud className="w-4 h-4 mr-2" />
              <span>{profilePicPreview ? 'Change' : 'Upload'}</span>
            </label>
            <Input id="empProfilePic" type="file" onChange={handleFileChange} className="hidden" accept="image/png, image/jpeg, image/gif" />
          </div>
        </div>
      </div>
      <div className="flex justify-end space-x-3 pt-4">
        {onCancel && <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>}
        <Button type="submit" className="btn-primary-custom">{initialData ? 'Save Changes' : 'Add Employee'}</Button>
      </div>
    </motion.form>
  );
};

const EmployeesPage = () => {
  const [employees, setEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const currentUser = localStorage.getItem('currentUser') || 'System';

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('employees_skv').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching employees", description: error.message, variant: "destructive" });
      setEmployees([]);
    } else {
      setEmployees(data);
    }
    setLoading(false);
  };

  const handleAddEmployee = async (employeeData) => {
    const { error } = await supabase.from('employees_skv').insert([employeeData]);
    if (error) {
      toast({ title: "Error adding employee", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Employee Added", description: `${employeeData.name} has been successfully added.` });
      await addLog({ userIdentity: currentUser, action: 'create', target: 'Employee', details: `Added employee: ${employeeData.name}` });
      fetchEmployees();
      setShowForm(false);
    }
  };

  const handleEditEmployee = async (updatedEmployee) => {
    const { error } = await supabase.from('employees_skv').update(updatedEmployee).eq('id', updatedEmployee.id);
    if (error) {
      toast({ title: "Error updating employee", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Employee Updated", description: `${updatedEmployee.name}'s details have been updated.` });
      await addLog({ userIdentity: currentUser, action: 'update', target: 'Employee', details: `Updated employee: ${updatedEmployee.name}` });
      fetchEmployees();
      setEditingEmployee(null);
      setShowForm(false);
    }
  };
  
  const handleDeleteEmployee = async (id) => {
    const employeeToDelete = employees.find(emp => emp.id === id);
    const { error } = await supabase.from('employees_skv').delete().eq('id', id);
    if (error) {
      toast({ title: "Error deleting employee", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Employee Deleted", description: `${employeeToDelete?.name || 'Employee'} has been deleted.`, variant: "destructive" });
      await addLog({ userIdentity: currentUser, action: 'delete', target: 'Employee', details: `Deleted employee: ${employeeToDelete?.name}` });
      fetchEmployees();
    }
  };

  const startEdit = (employee) => {
    setEditingEmployee(employee);
    setShowForm(true);
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingEmployee(null);
  }

  const filteredEmployees = employees.filter(emp =>
    emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="animate-fade-in-up space-y-8 flex flex-col">
      <BackButton />
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-center gap-4"
      >
        <h1 className="page-title-custom flex items-center"><UserCog className="w-8 h-8 mr-3 text-purple-500"/>Employee Directory</h1>
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-custom pl-10 w-full sm:w-64"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
          </div>
          <Button onClick={() => { setShowForm(true); setEditingEmployee(null); }} className="btn-primary-custom">
            <UserPlus className="w-5 h-5 mr-2" /> Add Employee
          </Button>
        </div>
      </motion.div>

      {showForm && (
        <EmployeeForm 
          onSubmit={editingEmployee ? handleEditEmployee : handleAddEmployee} 
          initialData={editingEmployee}
          onCancel={cancelForm}
        />
      )}
      {loading ? (
        <div className="text-center text-slate-500 py-10">Loading employees...</div>
      ) : filteredEmployees.length > 0 ? (
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredEmployees.map(emp => (
            <EmployeeCard key={emp.id} employee={emp} onDelete={handleDeleteEmployee} onEdit={startEdit} />
          ))}
        </motion.div>
      ) : (
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center text-slate-500 text-xl py-10"
        >
          No employees found. {searchTerm && "Try a different search term or "}add a new employee to get started!
        </motion.p>
      )}
    </div>
  );
};

export default EmployeesPage;