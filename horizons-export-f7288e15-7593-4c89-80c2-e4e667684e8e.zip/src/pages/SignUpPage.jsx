import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Mail, Lock, UserPlus, Building } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { addLog } from '@/lib/logger';

const SignUpPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !email || !password) {
        toast({
            title: 'Missing Fields',
            description: 'Please fill out all fields.',
            variant: 'destructive',
        });
        return;
    }

    // Check if email already exists in users_skv table
    const { data: existingUser, error: existingUserError } = await supabase
      .from('users_skv')
      .select('email')
      .eq('email', email)
      .single();

    if (existingUserError && existingUserError.code !== 'PGRST116') { // PGRST116 means no rows found, which is good here
      toast({
        title: 'Registration Error',
        description: 'Could not verify email. Please try again.',
        variant: 'destructive',
      });
      return;
    }
    
    if (existingUser) {
      toast({
        title: 'Registration Failed',
        description: 'An account with this email already exists in our records. Please try logging in.',
        variant: 'destructive',
      });
      return;
    }

    const { data: authData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { 
          name: name,
        }
      }
    });

    if (signUpError) {
      toast({
        title: 'Registration Failed',
        description: signUpError.message,
        variant: 'destructive',
      });
      return;
    }
    
    if (authData.user) {
      // Supabase Auth user created, now insert into users_skv table
      // We store "ENCRYPTED_IN_AUTH" as a placeholder because Supabase Auth handles the actual password.
      const { error: insertError } = await supabase
        .from('users_skv')
        .insert([{ name, email, password: "ENCRYPTED_IN_AUTH" }]); 

      if (insertError) {
        // This case might happen if, by a very small chance, another process created the user
        // in users_skv between the check and this insert, or if there's another constraint violation.
        // Or if Supabase Auth user exists but users_skv entry failed.
        toast({
          title: 'Registration Partially Failed',
          description: `Account created with Auth, but failed to save details in user records: ${insertError.message}. Please contact support.`,
          variant: 'destructive',
        });
        // Potentially, we might want to delete the authData.user here if the users_skv insert fails,
        // but that requires admin privileges and is complex. For now, log and notify.
        console.error("Failed to insert user into users_skv after auth signup:", insertError);
        return;
      }

      await addLog({
          userIdentity: name, 
          action: 'signup',
          target: 'User Account',
          details: `New user account created for ${email}`
      });

      toast({
          title: 'Registration Successful!',
          description: 'Your account has been created. Please check your email to confirm your account before logging in.',
      });
      navigate('/login');
    } else {
       toast({
          title: 'Registration Failed',
          description: 'An unexpected error occurred during Auth user creation. Please try again.',
          variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex bg-white">
      <div className="hidden lg:block relative w-0 flex-1">
        <img className="absolute inset-0 h-full w-full object-cover" alt="Collaborative workspace" src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f" />
      </div>
      <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto w-full max-w-sm lg:w-96"
        >
          <div>
            <div className="flex items-center text-purple-600">
                <Building className="h-8 w-8 mr-2" />
                <h2 className="text-3xl font-bold">SKV Company</h2>
            </div>
            <h2 className="mt-6 text-3xl font-extrabold text-slate-900">
              Create a new account
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Join our team! It's quick and easy.
            </p>
          </div>

          <div className="mt-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="name" className="login-label-custom">Full Name</Label>
                <div className="mt-1">
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="input-custom"
                    placeholder="John Doe"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email-signup" className="login-label-custom">Email address</Label>
                <div className="mt-1">
                  <Input
                    id="email-signup"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input-custom"
                    placeholder="you@example.com"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="password-signup" className="login-label-custom">Password</Label>
                <div className="mt-1">
                  <Input
                    id="password-signup"
                    name="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input-custom"
                    placeholder="••••••••"
                  />
                </div>
              </div>
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button type="submit" className="w-full btn-primary-custom flex items-center justify-center space-x-2 py-3 text-base">
                  <UserPlus className="h-5 w-5" />
                  <span>Sign Up</span>
                </Button>
              </motion.div>
            </form>
            <p className="mt-6 text-center text-sm text-slate-600">
                Already have an account?{' '}
                <Link to="/login" className="page-link-custom">
                    Sign In
                </Link>
             </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SignUpPage;
