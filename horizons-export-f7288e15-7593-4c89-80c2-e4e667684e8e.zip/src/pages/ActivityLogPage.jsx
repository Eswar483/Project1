import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { History, User, Briefcase, FolderKanban, AlertCircle, Filter } from 'lucide-react';
import BackButton from '@/components/BackButton';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const LogItem = ({ log }) => {
  const getIcon = (target) => {
    if (target?.includes('Intern') || target?.includes('Employee') || target?.includes('User Account')) return <User className="w-5 h-5 text-purple-500" />;
    if (target?.includes('Project')) return <FolderKanban className="w-5 h-5 text-yellow-500" />;
    if (target?.includes('HR') || target?.includes('document')) return <Briefcase className="w-5 h-5 text-red-500" />;
    return <AlertCircle className="w-5 h-5 text-slate-500" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="flex items-start space-x-4 p-4 border-b border-slate-200 hover:bg-slate-50 transition-colors duration-150 rounded-md"
    >
      <div className="flex-shrink-0 mt-1">{getIcon(log.target)}</div>
      <div className="flex-grow">
        <div className="flex justify-between items-center">
          <p className="font-semibold text-slate-800">
            <span className="text-purple-600">{log.user_identity}</span> {log.action} <span className="text-slate-600">{log.target}</span>
          </p>
          <p className="text-xs text-slate-500">{new Date(log.timestamp).toLocaleString()}</p>
        </div>
        <p className="text-sm text-slate-500">{log.details}</p>
      </div>
    </motion.div>
  );
};

const ActivityLogPage = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterUser, setFilterUser] = useState('');
  const [filterAction, setFilterAction] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const fetchLogs = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('activity_logs_skv')
        .select('*')
        .order('timestamp', { ascending: false });

      if (error) {
        toast({ title: "Error fetching logs", description: error.message, variant: "destructive" });
        setLogs([]);
      } else {
        setLogs(data);
      }
      setLoading(false);
    };
    fetchLogs();
  }, [toast]);

  const filteredLogs = logs.filter(log => {
    const userMatch = filterUser ? log.user_identity?.toLowerCase().includes(filterUser.toLowerCase()) : true;
    const actionMatch = filterAction ? log.action?.toLowerCase().includes(filterAction.toLowerCase()) : true;
    return userMatch && actionMatch;
  });

  const uniqueUsers = [...new Set(logs.map(log => log.user_identity).filter(Boolean))];
  const uniqueActions = [...new Set(logs.map(log => log.action).filter(Boolean))];


  return (
    <div className="animate-fade-in-up space-y-8 flex flex-col">
      <BackButton />
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4 p-4 bg-white rounded-lg shadow-md"
      >
        <h1 className="page-title-custom flex items-center"><History className="w-8 h-8 mr-3 text-purple-500"/>Activity Log</h1>
        <div className="flex flex-col sm:flex-row gap-2 items-center">
           <Filter className="w-5 h-5 text-slate-500 hidden sm:block" />
           <select 
            value={filterUser} 
            onChange={(e) => setFilterUser(e.target.value)}
            className="input-custom sm:w-48"
          >
            <option value="">All Users</option>
            {uniqueUsers.map(user => <option key={user} value={user}>{user}</option>)}
          </select>
          <select 
            value={filterAction} 
            onChange={(e) => setFilterAction(e.target.value)}
            className="input-custom sm:w-48"
          >
            <option value="">All Actions</option>
            {uniqueActions.map(action => <option key={action} value={action}>{action}</option>)}
          </select>
        </div>
      </motion.div>

      <motion.div 
        className="bg-white rounded-lg shadow-lg border border-slate-200 overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        {loading ? (
          <div className="text-center text-slate-500 p-10">Loading logs...</div>
        ) : filteredLogs.length > 0 ? (
          <div className="divide-y divide-slate-200 max-h-[70vh] overflow-y-auto">
            {filteredLogs.map(log => (
              <LogItem key={log.id} log={log} />
            ))}
          </div>
        ) : (
          <div className="text-center text-slate-500 p-10">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 text-yellow-500" />
            <p className="text-xl">No activity logs match your filters or no logs available.</p>
            <p>Try adjusting your search or new activities will appear here.</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default ActivityLogPage;