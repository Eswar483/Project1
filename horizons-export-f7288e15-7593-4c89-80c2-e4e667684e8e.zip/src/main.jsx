import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { migrateLocalStorageToSupabase } from '@/lib/migration';

const runMigration = async () => {
  const migrationStatus = localStorage.getItem('skv_migration_status_v1');
  if (migrationStatus !== 'completed') {
    console.log("Starting data migration from localStorage to Supabase...");
    await migrateLocalStorageToSupabase();
    localStorage.setItem('skv_migration_status_v1', 'completed');
    console.log("Data migration completed.");
  } else {
    console.log("Data migration already completed.");
  }
};

runMigration().then(() => {
  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});